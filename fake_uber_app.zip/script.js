
let rides = JSON.parse(localStorage.getItem('rides') || '[]');

function renderTable() {
    const tbody = document.querySelector('#ridesTable tbody');
    tbody.innerHTML = '';
    rides.forEach((ride, index) => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${ride.date}</td>
            <td>${ride.time}</td>
            <td>${ride.from}</td>
            <td>${ride.to}</td>
            <td>${ride.price}₽</td>
            <td>${ride.driver}</td>
            <td>
                <button onclick="editRide(${index})">✏️</button>
                <button onclick="deleteRide(${index})">🗑️</button>
            </td>
        `;
        tbody.appendChild(row);
    });
    localStorage.setItem('rides', JSON.stringify(rides));
}

function addRide() {
    document.getElementById('rideForm').reset();
    document.getElementById('rideId').value = '';
    document.getElementById('rideFormModal').classList.remove('hidden');
}

function editRide(index) {
    const ride = rides[index];
    document.getElementById('rideId').value = index;
    document.getElementById('date').value = ride.date;
    document.getElementById('time').value = ride.time;
    document.getElementById('from').value = ride.from;
    document.getElementById('to').value = ride.to;
    document.getElementById('price').value = ride.price;
    document.getElementById('driver').value = ride.driver;
    document.getElementById('rideFormModal').classList.remove('hidden');
}

function deleteRide(index) {
    if (confirm('Удалить поездку?')) {
        rides.splice(index, 1);
        renderTable();
    }
}

function saveRide(event) {
    event.preventDefault();
    const index = document.getElementById('rideId').value;
    const ride = {
        date: document.getElementById('date').value,
        time: document.getElementById('time').value,
        from: document.getElementById('from').value,
        to: document.getElementById('to').value,
        price: document.getElementById('price').value,
        driver: document.getElementById('driver').value
    };
    if (index === '') {
        rides.push(ride);
    } else {
        rides[index] = ride;
    }
    closeForm();
    renderTable();
}

function closeForm() {
    document.getElementById('rideFormModal').classList.add('hidden');
}

renderTable();
